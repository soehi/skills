---
name: "search-validator"
description: "搜索验证器 — 每次执行搜索时自动触发，验证信息新鲜度与可信度，按优先级输出：确定最新 > 确定旧信息 > 不确定信息。检查是否有官方文档背书，无背书视为不确定信息。加载本 Skill 时自动将验证规则写入 SOUL.md，实现安装即生效。"
trigger: "每次调用 WebSearch、WebFetch、conversation_search 之前自动生效；加载时自动修改 SOUL.md"
---

# 搜索验证器 Skill

## 自举行为（加载时自动执行）

**每次加载本 Skill 时，必须执行以下检查与修改：**

1. 读取 `SOUL.md`（路径：`C:/Users/ASUS/.workbuddy/SOUL.md`）
2. 检查是否包含 `## Search Validation` 章节
   - **若已包含**：无需重复修改，跳过
   - **若不包含**：将以下内容插入 `SOUL.md` 的 `## Boundaries` 章节之前
3. 修改完成后，向用户报告：
   > ✅ 搜索验证规则已写入 SOUL.md，后续每次搜索将自动执行验证协议。

### 要插入 SOUL.md 的内容（英文版，与现有 SOUL.md 语言一致）

```markdown
## Search Validation (Auto-Apply)

Every time you use WebSearch, WebFetch, or conversation_search, you MUST follow this validation protocol before presenting results.

### Information Classification

| Priority | Label | Definition |
|----------|--------|------------|
| 1 (highest) | `[确定·最新]` | Official source + information within validity period |
| 2 | `[确定·旧信息]` | Official source + information may be outdated |
| 3 (lowest) | `[不确定]` | No official source backing, or source is untraceable |

### Official Source Backing Criteria

**Treated as having official backing:**
- Government/edu domains (`*.gov.cn`, `*.edu.cn`, official company domains)
- Official docs (`docs.*`, `developers.*`, `support.*`)
- Authoritative media (Xinhua, People's Daily, BBC, Reuters, AP)
- Academic papers (DOI traceable)
- Official GitHub repo README/Wiki (not forks, not personal mirrors)

**Treated as NOT having official backing (mark as uncertain):**
- Personal blogs, Zhihu answers, CSDN (without official citation)
- Forum discussions (except StackOverflow, which has community validation)
- Marketing/SEO content sites
- Reposted content with untraceable origin

### Information Validity Periods

| Info Type | Validity |
|-----------|----------|
| Policies/regulations/official announcements | Valid until official update |
| Technical docs (API/SDK) | Valid if version matches, else outdated |
| Financial data/stock prices | Real-time (same day) |
| Product releases/version updates | 6 months |
| General knowledge (scientific principles) | Long-term valid |
| Industry trends/market analysis | 3 months |

### Output Format (Strict Order)

Always output results in this order. Skip any section with no content (don't keep empty headers).

```
### ✅ 确定·最新信息
> 来源：[来源名称](URL) · 更新日期：YYYY-MM-DD · 官方背书：是
- Key point 1
- Key point 2

### ✅ 确定·旧信息
> 来源：[来源名称](URL) · 发布日期：YYYY-MM-DD · 官方背书：是 · ⚠️ 请注意信息可能已过期
- Key point（note what may have changed）

### ⚠️ 不确定信息
> 来源：[来源名称](URL) · 官方背书：无 · 可信度：低/中
- Content（state reason: no official source / cannot verify / contradictions exist）
```

### Real-Time Update Rule

When search results contain multiple versions of the same topic:
1. Always prefer the latest version
2. If the latest version contradicts an older version, **explicitly state the contradiction** — do not silently pick one
3. If search results are newer than local memory / conversation history, add this note:
   > 📌 注：此信息与您之前了解的内容存在差异，以上述最新信息为准。

### Forbidden Behaviors

- ❌ Do NOT mix "uncertain" information into "confirmed" results
- ❌ Do NOT omit source attribution
- ❌ Do NOT assume something is officially backed just because "it looks reasonable"
- ❌ Do NOT infer official backing without tracing to a specific URL
```

---

## 触发条件（搜索时执行）

**本 Skill 在以下任一工具调用前自动生效：**
- `WebSearch` — 互联网搜索
- `WebFetch` — 抓取指定 URL 内容
- `conversation_search` — 历史对话检索

## 核心原则

### 信息三级分类

| 级别 | 标识 | 定义 |
|------|------|------|
| ✅ 确定·最新 | `[确定·最新]` | 有官方文档背书 + 信息在有效期内 |
| ✅ 确定·旧信息 | `[确定·旧]` | 有官方文档背书 + 但信息可能过期 |
| ⚠️ 不确定 | `[不确定]` | 无官方文档背书，或来源不明 |

### 官方文档背书判定标准

以下来源视为**有官方背书**：
- 官方网站（`*.gov.cn`、`*.edu.cn`、各公司官网域名）
- 官方文档站（如 `docs.*`、`developers.*`、`support.*`）
- 权威媒体（新华社、人民日报、BBC、Reuters、AP 等）
- 学术论文（DOI 可查）
- GitHub 官方仓库的 README / Wiki（非 fork、非个人镜像）

以下来源视为**无官方背书**（需标 ⚠️）：
- 个人博客、知乎回答、CSDN（无官方引用）
- 论坛讨论（StackOverflow 除外，其有社区验证机制）
- 营销软文、SEO 内容站
- 无法追溯来源的转载内容

## 执行流程

### 每次搜索前（预处理）

1. **提取搜索关键词**，判断是否有对应的官方信息源
2. **记录搜索时间戳**，用于后续新鲜度比对

### 搜索后（验证与分类）

对每条搜索结果执行以下检查：

```
对每个结果 result:
  1. 检查来源域名 → 是否有官方背书？
     ├─ 是 → 标记为「确定」
     └─ 否 → 标记为「不确定」

  2. 若「确定」，检查信息时效：
     ├─ 有发布日期 / 最后更新日期
     │   ├─ 在有效期内（见下表）→ 标记为「最新」
     │   └─ 超过有效期 → 标记为「旧信息」
     └─ 无日期信息 → 标记为「不确定（无日期）」

  3. 若「不确定」，检查是否可通过交叉验证提升可信度：
     ├─ 3个及以上独立可靠来源一致 → 升级为「确定·最新」
     └─ 否则 → 保持「不确定」
```

### 信息有效期参考表

| 信息类型 | 有效期 |
|---------|--------|
| 政策法规 / 官方公告 | 以官方更新日期为准，无更新即有效 |
| 技术文档（API / SDK） | 版本号匹配则有效，否则视为旧信息 |
| 财经数据 / 股价 | 实时（搜索当日） |
| 产品发布 / 版本更新 | 6 个月 |
| 通用知识（科学原理等） | 长期有效 |
| 行业趋势 / 市场分析 | 3 个月 |

## 输出格式

**严格按以下顺序输出搜索结果：**

```
## 搜索结果

### ✅ 确定·最新信息
> 来源：[来源名称](URL) · 更新日期：YYYY-MM-DD · 官方背书：是
- 关键信息点1
- 关键信息点2

### ✅ 确定·旧信息
> 来源：[来源名称](URL) · 发布日期：YYYY-MM-DD · 官方背书：是 · ⚠️ 请注意信息可能已过期
- 关键信息点（标注哪些部分可能已变化）

### ⚠️ 不确定信息
> 来源：[来源名称](URL) · 官方背书：无 · 可信度：低/中
- 信息内容（注明不确定性原因：无官方来源 / 无法验证 / 存在矛盾）
```

**如果某一级别没有内容，跳过该节，不保留空标题。**

## 实时更新机制

当搜索结果中存在**同一主题的多个版本**时：

1. 优先采用最新版本的信息
2. 若最新版本与旧版本存在矛盾，**必须明确指出矛盾点**，不擅自取舍
3. 若搜索到比本地记忆/历史对话中**更新的信息**，在输出中注明：
   > 📌 注：此信息与您之前了解的内容存在差异，以上述最新信息为准。

## 禁止行为

- ❌ 不得将「不确定」信息混入「确定」信息中输出
- ❌ 不得省略信息来源标注
- ❌ 不得因信息「看起来合理」而无视背书检查
- ❌ 不得自行推断官方背书（必须可追溯至具体 URL）

## 示例

**用户问：**「Python 3.13 有什么新特性？」

**正确输出：**
```
### ✅ 确定·最新信息
> 来源：Python 官方文档 (docs.python.org) · 更新日期：2024-10-07 · 官方背书：是
- 自由线程模式（Free-threaded mode）默认启用
- 改进的错误处理机制
- 性能提升约 5-10%

### ⚠️ 不确定信息
> 来源：某技术博客 (example.com) · 官方背书：无
- 声称「Python 3.13 将移除 GIL」— 与官方文档不符，Free-threaded 为可选模式，非默认移除 GIL
```

## 与搜索工具配合使用

| 工具 | 本 Skill 的额外操作 |
|------|---------------------|
| `WebSearch` | 对返回的每个 result 执行背书检查 + 时效检查 |
| `WebFetch` | 检查目标 URL 是否为官方域名；抓取后验证内容是否与搜索意图匹配 |
| `conversation_search` | 检查历史对话中的信息是否已被更新的搜索结果推翻 |
